<?php
// procedural approach




?>