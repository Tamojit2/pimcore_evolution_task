<?php
// object approach




?>