<?php require_once('includes/header.php');?>
<?php require_once('includes/navigation.php');?>
<div class="row">
  <div class="column side">
  <?php require_once('includes/sidebar.php');?>
  </div>
  <div class="column middle">Column</div>
  <div class="column side">Column</div>
</div>
<?php require_once('includes/footer.php');?>

