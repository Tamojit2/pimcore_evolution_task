<div class="footer">
  <p>Footer</p>
</div>

</body>
</html>