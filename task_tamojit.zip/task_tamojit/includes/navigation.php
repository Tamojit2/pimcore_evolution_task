<ul>
  <li><a class="active" href="#home">Home</a></li>
  <li><a href="categories.php">Categories</a></li>
  <li><a href="articles.php">Articles</a></li>
  <li><a href="comments.php">Comments</a></li>
  <li style="float:right;"><a href="logout.php">Logout</a></li>
</ul>