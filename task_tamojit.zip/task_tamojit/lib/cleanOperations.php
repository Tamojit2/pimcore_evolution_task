<?php


function clean($data){
    // return the clean data for processing purpose
    /*
    require_once('config/db1.php');
    $data['user'] = mysqli_real_escape_string($con,$_POST['user']); 
    $data['email'] = mysqli_real_escape_string($con,$_POST['email']);
    $data['pwd'] = mysqli_real_escape_string($con,$_POST['pwd']);
    $data['description'] = mysqli_real_escape_string($con,$_POST['desc']);

    */
    
    return $data;
}



?>